/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++
SOURCE VERSION: SV1.0
AUTHOR: Paolo Weng
DATE: Apr 6, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import net.gupt.cs.jee.dao.SingerDao;
import net.gupt.cs.jee.vo.Singer;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

/**
 * Test SingerDao
 * 
 * @author Paolo Weng
 * @since 1.0
 */

public class SingerDaoTest {

	DaoFactory daoFactory = DaoFactory.getDaoFactory(DaoFactory.MY_SQL);

	/**
	 * Test method for
	 * {@link net.gupt.cs.jee.dao.SingerDao#createSinger(net.gupt.cs.jee.vo.Singer)}
	 * 
	 */
	@Test
	public void testCreateSinger() {
		Session session = daoFactory.createSessionByJdbc();
		SingerDao singerDao = daoFactory.getSingerDao(session);
		
		Transaction transaction = session.beginTransaction();
		
		Singer singer = new Singer();
		singer.setName("周璇");
		singer.setRank(1);
		int result = singerDao.createSinger(singer);
		
		assertTrue(result != 0);
		
		transaction.rollback();;
	}

	/**
	 * Test method for
	 * {@link net.gupt.cs.jee.dao.SingerDao#retrieveSingerByName(java.lang.String)}
	 * .
	 */
	@Test
	public void testRetrieveSingerByName() {
		Session session = daoFactory.createSessionByJdbc();
		SingerDao singerDao = daoFactory.getSingerDao(session);

		Transaction transaction = session.beginTransaction();
		
		// 测试成功找到singer的case
		Singer singer = new Singer();
		singer.setName("周璇");
		singer.setRank(1);
		singerDao.createSinger(singer);

		singer = singerDao.retrieveSingerByName("周璇");
		
		assertNotNull(singer);
		assertTrue("周璇".equals(singer.getName()));
		assertTrue(1 == singer.getRank());
		
		transaction.rollback();

		// 测试找不到singer的case
		singer = singerDao.retrieveSingerByName("周璇");
		assertNull(singer);
	}

	/**
	 * Test method for {@link net.gupt.cs.jee.dao.SingerDao#retrieveAllSinger()}
	 */
	@Test
	public void testRetrieveAllSinger() {
		Session session = daoFactory.createSessionByJdbc();
		SingerDao singerDao = daoFactory.getSingerDao(session);

		Transaction transaction = session.beginTransaction();
		
		// 测试返回的singer集合为空的case。

		singerDao.deleteAllSinger();

		List<Singer> singers = singerDao.retrieveAllSinger();
		assertTrue(singers.size() == 0);

		// 测试返回的singer集合不为空的case。
		Singer singer = new Singer();
		singer.setName("周璇");
		singer.setRank(1);
		singerDao.createSinger(singer);

		singers = singerDao.retrieveAllSinger();
		
		assertTrue(singers.size() != 0);

		transaction.rollback();
	}

	/**
	 * Test method for
	 * {@link net.gupt.cs.jee.dao.SingerDao#deleteSingerById(int)}.
	 */
	@Test
	public void testDeleteSingerById() {
		Session session = daoFactory.createSessionByJdbc();
		SingerDao singerDao = daoFactory.getSingerDao(session);

		Transaction transaction = session.beginTransaction();
		
		// 测试成功删除singer的case
		Singer singer = new Singer();
		singer.setName("周璇");
		singer.setRank(1);
		singerDao.createSinger(singer);

		singer = singerDao.retrieveSingerByName(singer.getName());
		int id = singer.getId();

		singerDao.deleteSingerById(id);
		
		singer = singerDao.retrieveSingerByName(singer.getName());
		
		assertTrue(singer == null);
		
		transaction.rollback();
	}

	/**
	 * Test method for {@link net.gupt.cs.jee.dao.SingerDao#deleteAllSinger()}.
	 */
	@Test
	public void testDeleteAllSinger() {
		Session session = daoFactory.createSessionByJdbc();
		SingerDao singerDao = daoFactory.getSingerDao(session);

		Transaction transaction = session.beginTransaction();
		
		// 测试成功删除singer的case
		Singer singer = new Singer();
		singer.setName("山口百惠");
		singer.setRank(1);
		singerDao.createSinger(singer);

		int result = singerDao.deleteAllSinger();
		
		assertTrue(result != 0);

		// 测试找不到待删除singer的case
		result = singerDao.deleteAllSinger();
		
		assertTrue(result == 0);

		transaction.rollback();
	}

	/**
	 * Test method for
	 * {@link net.gupt.cs.jee.dao.SingerDao#updateSingerRankByName(net.gupt.cs.jee.vo.Singer)}
	 * .
	 */
	@Test
	public void testUpdateSingerRankByName() {
		Session session = daoFactory.createSessionByJdbc();
		SingerDao singerDao = daoFactory.getSingerDao(session);

		Transaction transaction = session.beginTransaction();
		
		// 测试成功更新singer的case
		Singer singer = new Singer();
		singer.setName("动力火车");
		singer.setRank(7);
		singerDao.createSinger(singer);

		singer = new Singer();
		singer.setName("动力火车");
		singer.setRank(3);

		int result = singerDao.updateSingerRankByName(singer);
		
		assertTrue(result != 0);

		// 测试找不到待更新singer的case
		singerDao.deleteAllSinger();
		
		result = singerDao.updateSingerRankByName(singer);
		
		assertTrue(result == 0);

		transaction.rollback();
	}

}
