/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+VERSION HISTORY AS BELOW++++++++

VERSION: 1.0
AUTHOR: Paolo Weng
DATE: Apr 6, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.vo;

import java.util.Comparator;

/**
 * Singer类的对象的比较器，按照先rank再name再id的次序，用单例模式（singleton pattern）。
 * 
 * @author Paolo Weng
 * @since 1.0
 */

public class SingerRankComparator implements Comparator<Singer> {

    public static final SingerRankComparator INSTANCE = new SingerRankComparator();

    /*
     * 私有构造器，以便实现单例模式，即该类只有1个对象（实例）供其他类使用。
     */
    private SingerRankComparator() {
    }

    @Override
    public int compare(Singer singer1, Singer singer2) {

	// 先比较rank。
	int result = singer1.getRank() - singer2.getRank();

	// 若rank相等，再比较name。
	if (result == 0) {
	    result = singer1.getName().compareTo(singer2.getName());
	}

	// 若name也相等，再比较id。
	if (result == 0) {
	    result = singer1.getId() - singer2.getId();
	}
	return result;
    }

}
