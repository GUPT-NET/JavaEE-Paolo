/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++

VERSION: SV1.0
AUTHOR: Paolo Weng
DATE: Apr 6, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.service;

import java.util.List;

import net.gupt.cs.jee.dao.SingerDao;
import net.gupt.cs.jee.dao.DaoFactory;
import net.gupt.cs.jee.vo.Singer;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * Provide singer services using singleton pattern.
 * 
 * @author Paolo Weng
 * @since 6.0
 */

public class SingerService {

	public static final SingerService INSTANCE = new SingerService();

	private DaoFactory daoFactory = DaoFactory.getDaoFactory(DaoFactory.MY_SQL);

	private SingerService() {
	}

	/**
	 * 对Singer进行排名，若Singer不存在，则新建一个Singer，若Singer已存在，则更新其排名。
	 * 
	 * @param singer
	 *            Singer对象，包含name和rank属性值。
	 * 
	 * @return true 表示成功；false表示失败。
	 */
	public boolean rankSinger(Singer singer) {

		// 创建hibernate会话。
		Session session = daoFactory.createSession();

		// 创建DAO对象。
		SingerDao singerDao = daoFactory.getSingerDao(session);

		int result = 0;
		Transaction transaction = null;
		try {
			// 开启事务。
			transaction = session.beginTransaction();

			// 判断是否有同名的singer，若有则更新，若无则新建。
			Singer existingSinger = singerDao.retrieveSingerByName(singer
					.getName());
			if (existingSinger == null) {
				result = singerDao.createSinger(singer);
			} else {
				result = singerDao.updateSingerRankByName(singer);
			}

			// 提交事务。
			transaction.commit();

		} catch (HibernateException e) {

			// 若抛出异常，需回滚事务，最好如下显式地回滚。
			transaction.rollback();

			// 继续往外抛异常。
			throw e;

		} finally {
			// 关闭连接，以释放占用的资源。
			session.close();
		}
		return result != 0;
	}

	public void deleteSingerById(int id) {

		// 创建hibernate会话。
		Session session = daoFactory.createSession();

		Transaction transaction = null;
		try {
			// 开启事务。
			transaction = session.beginTransaction();

			// 创建DAO对象。
			SingerDao singerDao = daoFactory.getSingerDao(session);

			// 根据id删除singer
			singerDao.deleteSingerById(id);

			// 提交事务。
			transaction.commit();

		} catch (HibernateException e) {

			// 若抛出异常，需回滚事务，最好如下显式地回滚。
			transaction.rollback();

			// 继续往外抛异常。
			throw e;

		} finally {// 关闭连接，以释放被占用的资源。
			session.close();
		}
	}

	public List<Singer> retrieveAllSinger() {

		// 创建hibernate会话。
		Session session = daoFactory.createSession();

		Transaction transaction = null;
		List<Singer> result = null;
		try {
			// 开启事务。
			transaction = session.beginTransaction();

			// 创建DAO对象。
			SingerDao singerDao = daoFactory.getSingerDao(session);

			// 获取所有歌手。
			result = singerDao.retrieveAllSinger();

			// 提交事务。
			transaction.commit();

		} catch (HibernateException e) {

			// 若抛出异常，需回滚事务，最好如下显式地回滚。
			transaction.rollback();

			// 继续往外抛异常。
			throw e;

		} finally {// 关闭连接，以释放被占用的资源。
			session.close();
		}

		return result;
	}

	public Singer retrieveSingerByName(String name) {

		// 创建hibernate会话。
		Session session = daoFactory.createSession();

		Transaction transaction = null;
		Singer singer = null;
		try {
			// 开启事务。
			transaction = session.beginTransaction();

			// 创建DAO对象。
			SingerDao singerDao = daoFactory.getSingerDao(session);

			// 根据姓名，获取歌手。
			singer = singerDao.retrieveSingerByName(name);

			// 提交事务。
			transaction.commit();

		} catch (HibernateException e) {

			// 若抛出异常，需回滚事务，最好如下显式地回滚。
			transaction.rollback();

			// 继续往外抛异常。
			throw e;

		} finally {// 关闭连接，以释放被占用的资源。
			session.close();
		}

		return singer;
	}

}
