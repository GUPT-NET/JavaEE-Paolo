/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++

VERSION: SV1.0
AUTHOR: Paolo Weng
DATE: Apr 2, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import net.gupt.cs.jee.service.SingerService;

/**
 * Servlet implementation class SingerDeletionServlet
 *
 * @author Paolo Weng
 * @since 6.0
 */
@WebServlet("/singerDel")
public class SingerDeletionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public SingerDeletionServlet() {
	super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {
	
	// 先从request中取得待删singer的id，再删除singer
	String singerIdStr = request.getParameter("id");
	
	if (StringUtils.isNoneBlank(singerIdStr)) {
	    
	    int singerId = Integer.valueOf(singerIdStr);
	    
	    // 获得SingerService的单例。
	    SingerService singerService = SingerService.INSTANCE;
	    
	    // 调用SingerService的“根据id删除Singer”的服务
	    singerService.deleteSingerById(singerId);
	}

	// 将请求转发给SingerResultServlet，以重新取得删除后的所有singer
	RequestDispatcher dispatcher = request
		.getRequestDispatcher("/singerResult");
	dispatcher.forward(request, response);
    }

}
