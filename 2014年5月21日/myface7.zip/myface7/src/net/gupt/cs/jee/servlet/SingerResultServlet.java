/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++

VERSION: SV1.0
AUTHOR: Paolo Weng
DATE: Apr 2, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.servlet;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.CollectionUtils;

import net.gupt.cs.jee.service.SingerService;
import net.gupt.cs.jee.vo.Singer;
import net.gupt.cs.jee.vo.SingerRankComparator;

/**
 * Servlet implementation class SingerResultServlet
 *
 * @author Paolo Weng
 * @since 5.0
 */
@WebServlet(name="singerResultServlet", urlPatterns={"/singerResult"})
public class SingerResultServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public SingerResultServlet() {
	super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {

	// 获得SingerService的单例。
	SingerService singerService = SingerService.INSTANCE;
	
	// 调用SingerService的“取得当前所有singer”的服务。
	List<Singer> singerList = singerService.retrieveAllSinger();

	// 若取到值不为空，则排序后放入request箱，以供显示。

	if (CollectionUtils.isNotEmpty(singerList)) {
	    // 按排名+姓名+id，对Singer排序
	    Collections.sort(singerList, SingerRankComparator.INSTANCE);

	    // 将排序后的singer集合放入request箱的编号是requestSingers的抽屉
	    request.setAttribute("requestSingers", singerList);
	}

	// 将请求转发到iamasinger.jsp
	RequestDispatcher dispatcher = request
		.getRequestDispatcher("iamasinger.jsp");
	dispatcher.forward(request, response);
    }

}
