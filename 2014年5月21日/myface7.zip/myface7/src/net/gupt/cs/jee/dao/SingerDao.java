/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++

VERSION: SV1.0
AUTHOR: Paolo Weng
DATE: Apr 6, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.dao;

import java.util.List;

import net.gupt.cs.jee.vo.Singer;

import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * Data Access Object for Singer.
 * 
 * @author Paolo Weng
 * @since 6.0
 */

public class SingerDao {
	private Session session;

	public SingerDao(Session session) {
		this.session = session;
	}

	public Integer createSinger(Singer singer) {
		return (Integer) session.save(singer);
	}

	public Singer retrieveSingerByName(String name) {

		// 创建statement。
		// 若返回的是该表所有column，则可以省略“select id, name, rank”。
		String hql = "from Singer singer where singer.name = ?";
		Query query = session.createQuery(hql);
		query.setParameter(0, name); // 第1个参数从0开始。

		// 执行statement，并取得结果。
		@SuppressWarnings("unchecked")
		List<Singer> result = query.list();

		// 处理结果。
		Singer singer = null;
		if (CollectionUtils.isNotEmpty(result)) {
			singer = result.get(0);
		}

		return singer;
	}

	public List<Singer> retrieveAllSinger() {
		// 创建statement。
		String hql = "from Singer";
		Query query = session.createQuery(hql);

		// 执行statement，并取得结果。
		@SuppressWarnings("unchecked")
		List<Singer> result = query.list();
		
		return result;
	}

	public void deleteSingerById(int id) {
		// 根据id，找到带删除的记录。
		Singer singer = (Singer) session.get(Singer.class, new Integer(id));
		// 执行删除。
		session.delete(singer);
	}

	public int deleteAllSinger() {
		// 创建statement。
		String sql = "delete from singer";
		Query query = session.createSQLQuery(sql);

		// 执行statement，并取得结果。
		int result = query.executeUpdate();
		
		return result;
	}

	public int updateSingerRankByName(Singer singer) {
		// 创建statement。
		String hql = "update Singer singer set singer.rank = ? where singer.name = ?";
		Query query = session.createQuery(hql);
		query.setParameter(0, singer.getRank()); // 第1个参数从0开始。
		query.setParameter(1, singer.getName());

		// 执行statement，并取得结果。
		int result = query.executeUpdate();

		return result;
	}
}
