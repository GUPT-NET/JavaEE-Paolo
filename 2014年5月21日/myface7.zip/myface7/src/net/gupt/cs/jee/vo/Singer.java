/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+VERSION HISTORY AS BELOW++++++++

VERSION: 1.0
AUTHOR: Paolo Weng
DATE: Mar 24, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.vo;

import java.io.Serializable;

/**
 * I am a Singer.
 * 
 * @author Paolo Weng
 * @since 1.0
 */

public class Singer implements Serializable, Comparable<Singer> {

    private static final long serialVersionUID = 3004589173443586960L;

    private int id;
    private String name;
    private int rank;

    public Singer() {
    }

    public int getId() {
	return id;
    }

    public void setId(int id) {
	this.id = id;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public int getRank() {
	return rank;
    }

    public void setRank(int rank) {
	this.rank = rank;
    }

    /**
     * Singer类对象的默认排序原则，先比id再比name再比rank。
     * 
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(Singer singer) {

	// 先比较id。
	int result = getId() - singer.getId();

	// 若id相等，再比较name。
	if (result == 0) {
	    result = getName().compareTo(singer.getName());
	}

	// 若name也相等，再比较rank。
	if (result == 0) {
	    result = getRank() - singer.getRank();
	}

	return result;
    }

    @Override
    public String toString() {
	return "Singer [id=" + id + ", name=" + name + ", rank=" + rank + "]";
    }
}
