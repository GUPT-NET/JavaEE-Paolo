/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++

VERSION: SV1.0
AUTHOR: Paolo Weng
DATE: Apr 11, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

/**
 * MySQL的DAO工厂，以获取数据库连接。设计模式使用单例模式。
 * 
 * @author Paolo Weng
 * @since 6.0
 */

public class MySqlDaoFactory extends DaoFactory {

	public static final MySqlDaoFactory INSTANCE = new MySqlDaoFactory(); // 单例，在装载该类时就创建。

	private static SessionFactory sessionFactory;
	
	private static SessionFactory sessionFactoryByJdbc;
	
	/*
	 * 私有构造器，以便实现单例模式，即该类只有1个对象（实例）供其他类使用。
	 */
	private MySqlDaoFactory() {
	}

	@Override
	public Session createSession() {
		// 优化创建Hibernate Session Factory的方式，多次请求只需创建1次Session Factory。
		if (sessionFactory == null) {
			sessionFactory = getSessionFactory();
		}
		Session session = sessionFactory.openSession();
		return session;
	}
	
	@Override
	public Session createSessionByJdbc() {
		// 优化创建Hibernate Session Factory的方式，多次请求只需创建1次Session Factory。
		if (sessionFactoryByJdbc == null) {
			sessionFactoryByJdbc = getSessionFactoryByJdbc();
		}
		Session session = sessionFactoryByJdbc.openSession();
		return session;
	}

	@Override
	public SingerDao getSingerDao(Session session) {
		return new SingerDao(session);
	}

	/*
	 * 获取hibernate会话工厂，JNDI方式。
	 */
	private SessionFactory getSessionFactory() {
		SessionFactory sessionFactory = null;
		Configuration config = new Configuration();
		config.configure("net/gupt/cs/jee/dao/mysql.hibernate.cfg.xml");
		
		StandardServiceRegistryBuilder serviceRegistryBuilder = new StandardServiceRegistryBuilder();
		serviceRegistryBuilder.applySettings(config.getProperties());
		ServiceRegistry serviceRegistry = serviceRegistryBuilder.build();
		
		sessionFactory = config.buildSessionFactory(serviceRegistry);
		return sessionFactory;
	}
	
	/*
	 * 获取hibernate会话工厂，JDBC方式。
	 */
	private SessionFactory getSessionFactoryByJdbc() {
		SessionFactory sessionFactory = null;
		Configuration config = new Configuration();
		config.configure("net/gupt/cs/jee/dao/mysql.jdbc.hibernate.cfg.xml");
		
		StandardServiceRegistryBuilder serviceRegistryBuilder = new StandardServiceRegistryBuilder();
		serviceRegistryBuilder.applySettings(config.getProperties());
		ServiceRegistry serviceRegistry = serviceRegistryBuilder.build();
		
		sessionFactory = config.buildSessionFactory(serviceRegistry);
		return sessionFactory;
	}
}
