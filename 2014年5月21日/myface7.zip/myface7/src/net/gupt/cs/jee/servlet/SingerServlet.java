/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++

VERSION: SV1.0
AUTHOR: Paolo Weng
DATE: Apr 2, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.gupt.cs.jee.service.SingerService;
import net.gupt.cs.jee.vo.Singer;

import org.apache.commons.lang3.StringUtils;

/**
 * Servlet implementation class SingerServlet
 *
 * @author Paolo Weng
 * @since 3.0
 */

/* 用此标注，就不需在web.xml里配置 */
@WebServlet("/singer")
public class SingerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public SingerServlet() {
	super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {
	// 将请求转发到iamasinger.jsp
	RequestDispatcher dispatcher = request
		.getRequestDispatcher("iamasinger.jsp");
	dispatcher.forward(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {
	
	// 取得客户端请求中的name和rank参数值。
	String name = request.getParameter("name");
	String rank = request.getParameter("rank");

	// 判断name和rank是否为空。
	if (StringUtils.isNoneBlank(name) && StringUtils.isNoneBlank(rank)) {
	    
	    // 创建singer对象，其name和rank属性值设置为客户端发来的name和rank值。
	    Singer singer = new Singer();
	    singer.setName(name.trim()); // 先调用trim方法删除前后空格
	    singer.setRank(Integer.parseInt(rank)); // 先将rank由字符串型变为int型

	    // 获得SingerService的单例。
	    SingerService singerService = SingerService.INSTANCE;
	    
	    // 调用SingerService的Singer排名服务。
	    singerService.rankSinger(singer);
	}
	
	// 将请求转发到iamasinger.jsp
	RequestDispatcher dispatcher = request
		.getRequestDispatcher("iamasinger.jsp");
	dispatcher.forward(request, response);
    }

}
