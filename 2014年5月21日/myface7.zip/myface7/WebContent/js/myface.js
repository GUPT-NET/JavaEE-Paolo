/**
 * COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.
 */

function validate() {
	if (myform.name.value == "") {
		alert("请您输入歌手名");
		return false;
	}
	if (myform.rank.value == 0) {
		alert("请您选择歌手排名");
		return false;
	}
	return true;
}