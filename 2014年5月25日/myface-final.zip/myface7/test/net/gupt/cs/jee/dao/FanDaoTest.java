/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++
SOURCE VERSION: SV1.0
AUTHOR: Pan Jinghong
DATE: Apr 25, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import net.gupt.cs.jee.dao.FanDao;
import net.gupt.cs.jee.vo.Fan;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

/**
 * Test FanDao
 * 
 * @author Paolo Weng
 * @since 1.0
 */

public class FanDaoTest {

	DaoFactory daoFactory = DaoFactory.getDaoFactory(DaoFactory.MY_SQL);

	/**
	 * Test method for
	 * {@link net.gupt.cs.jee.dao.FanDao#createFan(net.gupt.cs.jee.vo.Fan)}
	 * 
	 */
	@Test
	public void testCreateFan() {
		Session session = daoFactory.createSessionByJdbc();
		FanDao fanDao = daoFactory.getFanDao(session);

		Transaction transaction = session.beginTransaction();

		Fan fan = new Fan();
		fan.setName("周璇");
		int result = fanDao.createFan(fan);

		assertTrue(result != 0);

		transaction.rollback();
		;
	}

	/**
	 * Test method for
	 * {@link net.gupt.cs.jee.dao.FanDao#retrieveFanByName(java.lang.String)} .
	 */
	@Test
	public void testRetrieveFanByName() {
		Session session = daoFactory.createSessionByJdbc();
		FanDao fanDao = daoFactory.getFanDao(session);

		Transaction transaction = session.beginTransaction();

		// 测试成功找到fan的case
		Fan fan = new Fan();
		fan.setName("周璇");
		fanDao.createFan(fan);

		fan = fanDao.retrieveFanByName("周璇");

		assertNotNull(fan);
		assertTrue("周璇".equals(fan.getName()));

		transaction.rollback();

		// 测试找不到fan的case
		fan = fanDao.retrieveFanByName("周璇");
		assertNull(fan);
	}

	/**
	 * Test method for {@link net.gupt.cs.jee.dao.FanDao#retrieveAllFan()}
	 */
	@Test
	public void testRetrieveAllFan() {
		Session session = daoFactory.createSessionByJdbc();
		FanDao fanDao = daoFactory.getFanDao(session);

		Transaction transaction = session.beginTransaction();

		// 测试返回的fan集合为空的case。

		fanDao.deleteAllFan();

		List<Fan> fans = fanDao.retrieveAllFan();
		assertTrue(fans.size() == 0);

		// 测试返回的fan集合不为空的case。
		Fan fan = new Fan();
		fan.setName("周璇");
		fanDao.createFan(fan);

		fans = fanDao.retrieveAllFan();

		assertTrue(fans.size() != 0);

		transaction.rollback();
	}

	/**
	 * Test method for {@link net.gupt.cs.jee.dao.FanDao#deleteFanById(int)}.
	 */
	@Test
	public void testDeleteFanById() {
		Session session = daoFactory.createSessionByJdbc();
		FanDao fanDao = daoFactory.getFanDao(session);

		Transaction transaction = session.beginTransaction();

		// 测试成功删除fan的case
		Fan fan = new Fan();
		fan.setName("周璇");
		fanDao.createFan(fan);

		fan = fanDao.retrieveFanByName(fan.getName());
		int id = fan.getId();

		fanDao.deleteFanById(id);

		fan = fanDao.retrieveFanByName(fan.getName());

		assertTrue(fan == null);

		transaction.rollback();
	}

	/**
	 * Test method for {@link net.gupt.cs.jee.dao.FanDao#deleteAllFan()}.
	 */
	@Test
	public void testDeleteAllFan() {
		Session session = daoFactory.createSessionByJdbc();
		FanDao fanDao = daoFactory.getFanDao(session);

		Transaction transaction = session.beginTransaction();

		// 测试成功删除fan的case
		Fan fan = new Fan();
		fan.setName("山口百惠");
		fanDao.createFan(fan);

		int result = fanDao.deleteAllFan();

		assertTrue(result != 0);

		// 测试找不到待删除fan的case
		result = fanDao.deleteAllFan();

		assertTrue(result == 0);

		transaction.rollback();
	}

}
