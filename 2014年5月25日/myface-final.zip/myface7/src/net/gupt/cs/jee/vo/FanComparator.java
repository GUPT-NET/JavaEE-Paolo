/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+VERSION HISTORY AS BELOW++++++++

VERSION: 1.0
AUTHOR: Pan jinghong
DATE: Aper 24, 2014 
DESCRIPTION: Modify SingerRankComparator class Comparator class
 */

/*
 COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

 +VERSION HISTORY AS BELOW++++++++

 VERSION: 1.0
 AUTHOR: Paolo Weng
 DATE: Apr 6, 2014
 DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.vo;

import java.util.Comparator;

/**
 * 类的对象的比较器，按照先name再id的次序，用单例模式（singleton pattern）。
 * 
 * @author Pan jinghong
 * @since 1.1
 */

public class FanComparator implements Comparator<Fan> {

	public static final FanComparator INSTANCE = new FanComparator();

	/*
	 * 私有构造器，以便实现单例模式，即该类只有1个对象（实例）供其他类使用。
	 */
	private FanComparator() {
	}

	public int compare(Fan fan1, Fan fan2) {

		// 先比较Name。
		int result = fan1.getName().compareTo(fan2.getName());

		// 若name相等，再比较Id。
		if (result == 0) {
			result = fan1.getId() - fan1.getId();
		}

		return result;
	}

}
