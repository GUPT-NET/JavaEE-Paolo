/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+VERSION HISTORY AS BELOW++++++++

VERSION: 1.0
AUTHOR: Pan jinghong
DATE: Aper 24, 2014 
DESCRIPTION: Modify Singer class Fan class
 */
package net.gupt.cs.jee.vo;

import java.io.Serializable;

/**
 * I am a Fan.
 * 
 * @author Pan jinghong
 * @since 1.0
 */

public class Fan implements Serializable, Comparable<Fan> {

	private static final long serialVersionUID = -7752722055613001936L;
	private int id;
	private String name;

	public Fan() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Singer类对象的默认排序原则，先比name再比id。
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Fan fan) {

		// 先比较Name。
		int result = getName().compareTo(fan.getName());

		// 若name相等，再比较Id。
		if (result == 0) {
			result = getId() - fan.getId();
		}

		return result;
	}

	@Override
	public String toString() {
		return "Fan [id=" + id + ", name=" + name + "]";
	}
}
