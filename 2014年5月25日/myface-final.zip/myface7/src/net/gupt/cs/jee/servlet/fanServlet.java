/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+VERSION HISTORY AS BELOW++++++++

VERSION: 1.0
AUTHOR: Pan jinghong
DATE: Aper 24, 2014 
DESCRIPTION: Modify SingerServlet class FansServlet class
 */

package net.gupt.cs.jee.servlet;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.collections4.CollectionUtils;
import net.gupt.cs.jee.service.FanService;
import net.gupt.cs.jee.vo.Fan;
import net.gupt.cs.jee.vo.FanComparator;

/**
 * Servlet implementation class fanServlet
 */
@WebServlet("/fan")
public class fanServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public fanServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// 获得FansService的单例。
		FanService fanService = FanService.INSTANCE;

		// 调用FansService的“取得当前所有fans”的服务。
		List<Fan> fanList = fanService.retrieveAllFan();

		// 若取到值不为空，则排序后放入request箱，以供显示。

		if (CollectionUtils.isNotEmpty(fanList)) {
			// 按姓名+id，对fans排序
			Collections.sort(fanList, FanComparator.INSTANCE);

			// 将排序后的fans集合放入request箱的编号是requestfans的抽屉
			request.setAttribute("requestFans", fanList);
		}

		// 将请求转发到fan.jsp
		RequestDispatcher dispatcher = request.getRequestDispatcher("fan.jsp");
		dispatcher.forward(request, response);
	}

}
