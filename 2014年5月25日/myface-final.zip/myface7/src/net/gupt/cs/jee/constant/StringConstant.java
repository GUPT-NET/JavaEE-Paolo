/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++

VERSION: SV1.0
AUTHOR: Paolo Weng
DATE: Mar 24, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.constant;

/**
 * String type of constant variables.
 * 
 * @author Paolo Weng
 * @since 1.0
 */
public final class StringConstant {

    private StringConstant() {
    }

    /*
     * Session attribute name
     */
    public static final String SESSION_FANS = "sessionFans";
    public static final String SESSION_SINGERS = "sessionSingers";
}
