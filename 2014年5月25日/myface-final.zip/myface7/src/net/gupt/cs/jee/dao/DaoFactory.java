/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++

VERSION: SV1.1
AUTHOR: Paolo Weng
DATE: Apr 11, 2014
DESCRIPTION: Add getFanDao() 
 */
/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++

VERSION: SV1.0
AUTHOR: Paolo Weng
DATE: Apr 11, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.dao;

import net.gupt.cs.jee.dao.DaoFactory;
import net.gupt.cs.jee.dao.MySqlDaoFactory;

import org.hibernate.Session;

/**
 * 抽象的DAO工厂，其子类可以是各数据库的DAO工厂。设计模式使用工厂模式。
 * 
 * @author Paolo Weng
 * @since 6.0
 */

public abstract class DaoFactory {

	public static final int MY_SQL = 1;

	// public static final int ORACLE = 2;
	// public static final int SQL_SERVER = 3;

	/**
	 * 创建Hibernate Session，用JNDI获取数据源的方式。
	 */
	public abstract Session createSession();

	/**
	 * 创建Hibernate Session，直接用JDBC的方式。
	 */
	public abstract Session createSessionByJdbc();

	/**
	 * 创建Singer的数据访问对象。
	 */
	public abstract SingerDao getSingerDao(Session session);

	/**
	 * 创建Fan的数据访问对象。
	 */
	public abstract FanDao getFanDao(Session session);

	/**
	 * 根据传入参数，创建相应的数据访问对象工厂。可视为简单的工厂模式。
	 */
	public static DaoFactory getDaoFactory(int whichFactory) {

		switch (whichFactory) {
		case MY_SQL:
			return MySqlDaoFactory.INSTANCE;
			// case ORACLE :
			// return new OracleDaoFactory();
			// case SQL_SERVER :
			// return new SqlServerDaoFactory();
		default:
			return null;
		}
	}
}
