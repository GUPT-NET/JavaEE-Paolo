/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++

VERSION: SV1.0
AUTHOR: Paolo Weng
DATE: Apr 2, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.servlet;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.gupt.cs.jee.constant.StringConstant;
import net.gupt.cs.jee.service.FanService;
import net.gupt.cs.jee.vo.Fan;

/**
 * Servlet implementation class HelloServlet
 * 
 * @author Paolo Weng
 * @since 3.0
 */
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HelloServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// 取得客户端发来的userNme
		String userName = request.getParameter("userName");

		// 设置转发的页面，默认为index
		RequestDispatcher dispatcher = request
				.getRequestDispatcher("index.html");

		// 若userName有值，就将其放入session
		if (userName != null && userName.length() > 0) {

			// 取得当前request对应的session，若没有，则创建1个session。
			HttpSession session = request.getSession(true);

			// 尝试从session中取得userName集合
			@SuppressWarnings("unchecked")
			Set<String> fanSet = (Set<String>) session
					.getAttribute(StringConstant.SESSION_FANS);

			// 若当前session中的userName集合为空，则创建1个集合
			if (fanSet == null) {
				fanSet = new HashSet<String>(7);
			}

			// 将客户端发来的userName加入当前fanName集合，并存入session。
			fanSet.add(userName);
			session.setAttribute(StringConstant.SESSION_FANS, fanSet);

			// 设置转发页面为hello.jsp
			dispatcher = request.getRequestDispatcher("hello.jsp");

			// 创建Fans对象，其name属性值设置为客户端发来的name值。
			Fan fan = new Fan();
			fan.setName(userName);
			// 获得FansService的单例。
			FanService fansService = FanService.INSTANCE;

			// 调用FansService的Fans排名服务。
			fansService.rankFan(fan);

		}

		// 转发
		dispatcher.forward(request, response);
	}
}
