/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++

VERSION: SV1.0
AUTHOR: Pan JingHong
DATE: Apr 21, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.service;

import java.util.List;

import net.gupt.cs.jee.dao.DaoFactory;
import net.gupt.cs.jee.dao.FanDao;
import net.gupt.cs.jee.vo.Fan;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * Provide fan services using singleton pattern.
 * 
 * @author Paolo Weng
 * @since 6.0
 */

public class FanService {

	public static final FanService INSTANCE = new FanService();

	private DaoFactory daoFactory = DaoFactory.getDaoFactory(DaoFactory.MY_SQL);

	private FanService() {
	}

	/**
	 * 对Fan进行排名，若Fan不存在，则新建一个Fan，若Fan已存在，则更新其排名。
	 * 
	 * @param fan
	 *            Fan对象，包含name和rank属性值。
	 * 
	 * @return true 表示成功；false表示失败。
	 */
	public boolean rankFan(Fan fan) {

		// 创建hibernate会话。
		Session session = daoFactory.createSession();

		// 创建DAO对象。
		FanDao fanDao = daoFactory.getFanDao(session);

		int result = 0;
		Transaction transaction = null;
		try {
			// 开启事务。
			transaction = session.beginTransaction();

			// 判断是否有同名的fan，若有则不修改，若无则新建。
			Fan existingFan = fanDao.retrieveFanByName(fan
					.getName());
			if (existingFan == null) {
				result = fanDao.createFan(fan);
			} else {
			}

			// 提交事务。
			transaction.commit();

		} catch (HibernateException e) {

			// 若抛出异常，需回滚事务，最好如下显式地回滚。
			transaction.rollback();

			// 继续往外抛异常。
			throw e;

		} finally {
			// 关闭连接，以释放占用的资源。
			session.close();
		}
		return result != 0;
	}

	public void deleteFanById(int id) {

		// 创建hibernate会话。
		Session session = daoFactory.createSession();

		Transaction transaction = null;
		try {
			// 开启事务。
			transaction = session.beginTransaction();

			// 创建DAO对象。
			FanDao fanDao = daoFactory.getFanDao(session);

			// 根据id删除fan
			fanDao.deleteFanById(id);

			// 提交事务。
			transaction.commit();

		} catch (HibernateException e) {

			// 若抛出异常，需回滚事务，最好如下显式地回滚。
			transaction.rollback();

			// 继续往外抛异常。
			throw e;

		} finally {// 关闭连接，以释放被占用的资源。
			session.close();
		}
	}

	public List<Fan> retrieveAllFan() {

		// 创建hibernate会话。
		Session session = daoFactory.createSession();

		Transaction transaction = null;
		List<Fan> result = null;
		try {
			// 开启事务。
			transaction = session.beginTransaction();

			// 创建DAO对象。
			FanDao fanDao = daoFactory.getFanDao(session);

			// 获取所有歌手。
			result = fanDao.retrieveAllFan();

			// 提交事务。
			transaction.commit();

		} catch (HibernateException e) {

			// 若抛出异常，需回滚事务，最好如下显式地回滚。
			transaction.rollback();

			// 继续往外抛异常。
			throw e;

		} finally {// 关闭连接，以释放被占用的资源。
			session.close();
		}

		return result;
	}

	public Fan retrieveFanByName(String name) {

		// 创建hibernate会话。
		Session session = daoFactory.createSession();

		Transaction transaction = null;
		Fan fan = null;
		try {
			// 开启事务。
			transaction = session.beginTransaction();

			// 创建DAO对象。
			FanDao fanDao = daoFactory.getFanDao(session);

			// 根据姓名，获取歌手。
			fan = fanDao.retrieveFanByName(name);

			// 提交事务。
			transaction.commit();

		} catch (HibernateException e) {

			// 若抛出异常，需回滚事务，最好如下显式地回滚。
			transaction.rollback();

			// 继续往外抛异常。
			throw e;

		} finally {// 关闭连接，以释放被占用的资源。
			session.close();
		}

		return fan;
	}

}
