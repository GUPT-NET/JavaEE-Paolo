/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+SOURCE VERSION HISTORY AS BELOW++++++++

VERSION: SV1.0
AUTHOR: Pan　JingHong
DATE: Apr 21, 2014
DESCRIPTION: Initial Version
 */

package net.gupt.cs.jee.dao;

import java.util.List;

import net.gupt.cs.jee.vo.Fan;

import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * Data Access Object for Fan.
 * 
 * @author Paolo Weng
 * @since 6.0
 */

public class FanDao {
	private Session session;

	public FanDao(Session session) {
		this.session = session;
	}

	public Integer createFan(Fan fan) {
		return (Integer) session.save(fan);
	}

	public Fan retrieveFanByName(String name) {

		// 创建statement。
		// 若返回的是该表所有column，则可以省略“select id, name, rank”。
		String hql = "from Fan s where s.name = ?";
		Query query = session.createQuery(hql);
		query.setParameter(0, name); // 第1个参数从0开始。

		// 执行statement，并取得结果。
		@SuppressWarnings("unchecked")
		List<Fan> result = query.list();

		// 处理结果。
		Fan fan = null;
		if (CollectionUtils.isNotEmpty(result)) {
			fan = result.get(0);
		}

		return fan;
	}

	public List<Fan> retrieveAllFan() {
		// 创建statement。
		String hql = "from Fan";
		Query query = session.createQuery(hql);

		// 执行statement，并取得结果。
		@SuppressWarnings("unchecked")
		List<Fan> result = query.list();

		return result;
	}

	public void deleteFanById(int id) {
		// 根据id，找到带删除的记录。
		Fan fan = (Fan) session.get(Fan.class, new Integer(id));
		// 执行删除。
		session.delete(fan);
	}

	public int deleteAllFan() {
		// 创建statement。
		String sql = "delete from fan";
		Query query = session.createSQLQuery(sql);

		// 执行statement，并取得结果。
		int result = query.executeUpdate();

		return result;
	}

}
