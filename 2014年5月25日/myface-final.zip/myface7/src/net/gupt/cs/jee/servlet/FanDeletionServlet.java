/*
COPYRIGHT (C) 2014 BY GUPT SOFTWARE. ALL RIGHTS RESERVED.

+VERSION HISTORY AS BELOW++++++++

VERSION: 1.0
AUTHOR: Pan jinghong
DATE: Aper 24, 2014 
DESCRIPTION: Modify SingerDeletionServlet class FansDeletionServlet class
 */

package net.gupt.cs.jee.servlet;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.gupt.cs.jee.service.FanService;
import org.apache.commons.lang3.StringUtils;

/**
 * Servlet implementation class FansDeletionServlet
 */
@WebServlet("/fansdel")
public class FanDeletionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FanDeletionServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// 先从request中取得待删fans的id，再删除fansr
		String fansIdStr = request.getParameter("id");

		if (StringUtils.isNoneBlank(fansIdStr)) {

			int fansId = Integer.valueOf(fansIdStr);

			// 获得fansService的单例。
			FanService fansService = FanService.INSTANCE;

			// 调用fansService的“根据id删除fansr”的服务
			fansService.deleteFanById(fansId);
		}

		// 将请求转发给fansResultServlet，以重新取得删除后的所有fans
		RequestDispatcher dispatcher = request.getRequestDispatcher("/fan");
		dispatcher.forward(request, response);
	}
}
